function convertCurrencies() {
    var real = document.getElementById('real');
    var dolar = document.getElementById('dolar');
    var euro = document.getElementById('euro');

    real.addEventListener('input', function() {
        if (real.value !== '') {
            dolar.value = (real.value / 4.50).toFixed(2);
            euro.value = (real.value / 5.15).toFixed(2);
        }
    });

    dolar.addEventListener('input', function() {
        if (dolar.value !== '') {
            real.value = (dolar.value * 4.50).toFixed(2);
            euro.value = (dolar.value * (4.50 / 5.15)).toFixed(2);
        }
    });

    euro.addEventListener('input', function() {
        if (euro.value !== '') {
            real.value = (euro.value * 5.15).toFixed(2);
            dolar.value = (euro.value * (5.15 / 4.50)).toFixed(2);
        }
    });
}

function clearFields() {
    document.getElementById('real').value = '';
    document.getElementById('dolar').value = '';
    document.getElementById('euro').value = '';
}

document.addEventListener('DOMContentLoaded', function() {
    convertCurrencies();
});
